class A { A() {} }

class Main {
    public static void main(String args[]) {
	String s = (String)(Object)new A();
    }
}
