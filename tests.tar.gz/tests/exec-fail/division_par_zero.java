class Main {
    public static void main(String args[]) {
	int x = 1 / 0;
    }
}
