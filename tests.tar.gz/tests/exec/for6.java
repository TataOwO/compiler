class Main {
    public static void main(String args[]) {
	int i = 0;
	for( ; i < -1; System.out.print("ko\n"))
	    return;
	System.out.print("ok\n");
    }
}
