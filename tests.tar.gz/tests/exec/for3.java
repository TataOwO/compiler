class Main {
    public static void main(String args[]) {
	int sum = 0;
        int i;
	for(i = 4; i > 0; i=i-1)
	    sum = sum + i;
	if (sum == 10)
	    System.out.print("ok\n");
    }
}
