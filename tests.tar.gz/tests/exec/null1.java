class Main {
    public static void main(String args[]) {
        Object o = null;
        if (o == null)
            System.out.print("null\n");
        o = "toto";
        if (o == null)
            System.out.print("null\n");
    }
}

