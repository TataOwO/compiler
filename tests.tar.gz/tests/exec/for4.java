class Main {
    public static void main(String args[]) {
	int i;
	for(i = 2; i > 0; i=i-1) ;
	if (i == 0)
	    System.out.print("ok\n");
    }
}
