class Main {
    public static void main(String args[]) { 

	if (true || 0 / 0 == 0) System.out.print("ok\n");
    }
}
