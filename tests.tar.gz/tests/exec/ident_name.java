class Main {
    public static void main(String args[]) {
	boolean ___________ = true;
	int ____1_____023__ = 0;
	if (___________ && ____1_____023__ == 0)
	    System.out.print("ok\n");
    }
}
