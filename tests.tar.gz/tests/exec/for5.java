class Main {
    public static void main(String args[]) {
        int i;
	for(i = 0; i < 1; System.out.print("ok\n")) i=i+1;
    }
}
