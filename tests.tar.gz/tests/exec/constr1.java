class A {
    A() {
	System.out.print("ok\n");
    }
}

class Main {
    public static void main(String args[]) {
	A a = new A();
    }
}
