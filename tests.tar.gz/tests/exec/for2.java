class Main {
    public static void main(String args[]) {
	int sum = 0;
        int i;
	for(i = 0; i < 4; i=i+1)
	    sum = sum + i;
	if (sum == 6)
	    System.out.print("ok\n");
    }
}
