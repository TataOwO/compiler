class Main {
    public static void main(String args[]) { System.out.print("ok\n"); }
}
