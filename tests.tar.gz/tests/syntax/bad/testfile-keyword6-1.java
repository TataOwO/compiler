class A { void m() { int x = 0 instanceo boolean; } }
class Main { public static void main(String args[]) { } }
