class A { void m() { for(int i = 0; true; i = 0,) ; } }
class Main { public static void main(String args[]) { } }
