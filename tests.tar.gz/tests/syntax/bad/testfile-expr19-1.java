class A {
    void m() { int i = new A; }
}
class Main { public static void main(String args[]) { } }
