class A { void m() { for(int i = 0; true; i=i+1) } }
class Main { public static void main(String args[]) { } }
