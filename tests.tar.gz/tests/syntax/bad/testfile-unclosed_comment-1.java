
class A { }

/*
class B extends A {
    void g() { g(this,this); }
    void g(A a, B b) { }
    void g(B b, A a) { }
}
class Main { public static void main(String args[]) { } }
