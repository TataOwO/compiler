class A { A a; void m() { int x = a.x = ; } }
class Main { public static void main(String args[]) { } }
