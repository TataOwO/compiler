class A {
    int x = 01;
}
class Main { public static void main(String args[]) { } }
