class A {
        int foo(int a, int b) {
            return a--b;
        }

class Main { public static void main(String args[]) { } }
