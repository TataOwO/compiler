class A {
    int i;
    int meth (int j)}
class Main { public static void main(String args[]) { } }
