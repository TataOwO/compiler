class A {
    void m() { int i = j.1 = 2 ; }
}
class Main { public static void main(String args[]) { } }
