class A { int m() { if (true) } }
class Main { public static void main(String args[]) { } }
