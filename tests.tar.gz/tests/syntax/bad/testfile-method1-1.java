class A { void int m() {} }
class Main { public static void main(String args[]) { } }
