class A { void m(int) {} }
class Main { public static void main(String args[]) { } }
