class A { void m() { int x = new 0; } }
class Main { public static void main(String args[]) { } }
