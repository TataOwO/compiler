class A {
    void m() { A i = j ++ i ; }
}
class Main { public static void main(String args[]) { } }
