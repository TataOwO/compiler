import java.util.*;
class A { }
class Main { public static void main(String args[]) { } }
