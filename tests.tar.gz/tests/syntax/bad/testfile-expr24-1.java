class A {
    void m() { A i == i ; }
}
class Main { public static void main(String args[]) { } }
