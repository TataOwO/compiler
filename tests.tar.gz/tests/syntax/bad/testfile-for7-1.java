class A { void m() { int i; for() ; } }
class Main { public static void main(String args[]) { } }
