class A {
    void m() { int i = 0; i + = 10; }
}
class Main { public static void main(String args[]) { } }
