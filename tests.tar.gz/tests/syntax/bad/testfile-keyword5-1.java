class A { void m() { A a = newa A(); A() {}} }
class Main { public static void main(String args[]) { } }
