
class A {}
class M { void m() { A a = null; } }
class Main { public static void main(String args[]) { } }
