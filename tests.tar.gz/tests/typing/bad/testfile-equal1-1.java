class A { void m() { int b = true == true; } }
class Main { public static void main(String args[]) { } }
