class A extends String { }
class Main { public static void main(String args[]) { } }
