class A { void m() { int x = y; } }
class Main { public static void main(String args[]) { } }
