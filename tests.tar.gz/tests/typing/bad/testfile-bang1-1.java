class A { void m() { boolean b = ! 1; } }
class Main { public static void main(String args[]) { } }
