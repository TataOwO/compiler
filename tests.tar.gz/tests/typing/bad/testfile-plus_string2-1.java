class M { void m() { String s = true + ""; } }
class Main { public static void main(String args[]) { } }
