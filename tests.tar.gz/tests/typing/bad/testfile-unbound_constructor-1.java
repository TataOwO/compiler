class A { void m() { A a = new A(); } A(int x) { } }
class Main { public static void main(String args[]) { } }
