class A { void m() { int x = true && true; } }
class Main { public static void main(String args[]) { } }
