class A {
    A a;
    void m() { boolean x = 1 + a instanceof A;
               boolean y = ! a instanceof A; }
}
class Main { public static void main(String args[]) { } }
