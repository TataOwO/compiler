class A { void m() { int x = 0; int y = ((Object)new A()).x; } }

class Main { public static void main(String args[]) { } }
