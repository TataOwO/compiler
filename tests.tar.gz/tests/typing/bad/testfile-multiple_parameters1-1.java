class A {
    void m(int x, int y, int z, int y, int t) { }
}
class Main { public static void main(String args[]) { } }
