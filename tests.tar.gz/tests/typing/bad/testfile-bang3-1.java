class A { void m() { int b = ! true; } }
class Main { public static void main(String args[]) { } }
