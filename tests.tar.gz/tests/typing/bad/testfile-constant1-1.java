class A {
    void m() { boolean x = 1; }
}
class Main { public static void main(String args[]) { } }
