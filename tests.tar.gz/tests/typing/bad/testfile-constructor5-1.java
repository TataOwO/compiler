class A {
    A(int x) { }

    void m() { A a = new A(1, 2); }
}
class Main { public static void main(String args[]) { } }
