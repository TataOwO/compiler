class A { A() { } }
class B {
    void main() { if ((new A()) instanceof String) ; }
}
class Main { public static void main(String args[]) { } }
