class A {
    void m() { boolean x = true; int y = x; }
}
class Main { public static void main(String args[]) { } }
