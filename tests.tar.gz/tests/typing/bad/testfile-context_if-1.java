class A { void m() { if (true) int x = 1; x = 2; } }
class Main { public static void main(String args[]) { } }
