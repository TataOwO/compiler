class A { void m() { A a = (A)(int)0; } }
class Main { public static void main(String args[]) { } }
