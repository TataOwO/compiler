class A { A a; void m() { int x = A.f; } }
class Main { public static void main(String args[]) { } }
