class A {
    A(int x) { }
    void m() { A a = new A(); }
}
class Main { public static void main(String args[]) { } }
