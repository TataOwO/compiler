class A { A() {} }

class B { void main() { String s = (String)new A(); } }

class Main { public static void main(String args[]) { } }
