class A { A() {} }

class B { void m() { A a = (A)"tutu"; } }

class Main { public static void main(String args[]) { } }
