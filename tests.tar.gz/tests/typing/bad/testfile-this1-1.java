class A { }

class B {
    void m() { A x = this; }
}
class Main { public static void main(String args[]) { } }
