class A { void m() { int x = (int)(A)1; } }
class Main { public static void main(String args[]) { } }
