class A { A a; void m() { int x = A.m(); } }
class Main { public static void main(String args[]) { } }
