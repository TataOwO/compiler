class A { void m() { int x = (int)(boolean)true; } }
class Main { public static void main(String args[]) { } }
