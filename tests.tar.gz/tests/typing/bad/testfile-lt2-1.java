class A { void m() { boolean b = 1 > true; } }
class Main { public static void main(String args[]) { } }
