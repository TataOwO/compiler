class A { void m() { boolean b = ! null; } }
class Main { public static void main(String args[]) { } }
