class A { void m() { int x = y; int y = 1; } }
class Main { public static void main(String args[]) { } }
