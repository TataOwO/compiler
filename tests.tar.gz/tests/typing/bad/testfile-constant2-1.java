class A {
    void m() { int x = true; }
}
class Main { public static void main(String args[]) { } }
