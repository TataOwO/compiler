class A { }
class B { B() { } }

class M {
    void main() { boolean b = new B() instanceof A; }
}
class Main { public static void main(String args[]) { } }
