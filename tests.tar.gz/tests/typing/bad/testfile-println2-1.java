class M { void m() { System.out.println(null); } }
class Main { public static void main(String args[]) { } }
