class M {
    void main() { boolean b = 1 instanceof int; }
}
class Main { public static void main(String args[]) { } }
