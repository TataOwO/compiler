class A { void m() { int x = "" instanceof String; } }
class Main { public static void main(String args[]) { } }
