class A { int m() { return true; } }
class Main { public static void main(String args[]) { } }
