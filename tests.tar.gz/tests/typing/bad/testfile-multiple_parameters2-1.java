class A {
    A(int x, int y, boolean x) { }
}
class Main { public static void main(String args[]) { } }
