class M {
    void main() { boolean b = 1 instanceof Object; }
}
class Main { public static void main(String args[]) { } }
