class M { void m() { System.out.println(1); } }
class Main { public static void main(String args[]) { } }
